import requests
import json
import pandas as pd

from bs4 import BeautifulSoup


def teste_new_admet(smiles_list: list):
    url = "https://admetlab3.scbdd.com/api/admet"
    data = {
        "SMILES": smiles_list,
        "feature": False
    }
    response = requests.post(url, json=data)
    response_json = response.json()
    data = response_json['data']['data']
    filtered_data = [d for d in data if 'Invalid Molecule' not in d.values()]

    with open('teste.txt', 'w') as f:
        f.write(json.dumps(filtered_data, indent=4))
def get_admet_results():
    with open('teste.json', 'r') as f:
        json_file = json.load(f)

    #df = pd.DataFrame(data)
    #df.to_csv('admet_results.csv', index=False)


if __name__ == '__main__':
    #lista_smiles = ["CC(C)OC(=O)CC(=O)CSc1nc2c(cc1C#N)CCC2", "C1=CC=C(C=C1)C(=O)NC2=C(N=C(S2)N)C3=CC=CS3", "CC(C)OC(=O)CC(=O)CSC1=C(C=C2CCCC2=N1)C#N", "C1CCC2(CC1)NC3=CC(=C(C#N)C#N)C=CC3=N2", "CCC1=NNC2=C1/C(=N\O)/CC(C2)C3=CC=CC=C3", "CN1C2=CC=CC=C2N=C1SC3=CS(=O)(=O)C4=CC=CC=C43", "O=C(O)Nc1scnc1C(=O)Nc1nccs1", "O=c1cc(-c2ccccc2Cl)oc2c(NS(=O)(=O)c3ccccc3C(F)(F)F)ccc(O)c12", "CCc1cccc(C=CC2C3CCCCC3CC3C(=O)OC(C)C32)n1", "CC(C)CN(Cc1ccc(N2CCC(N(C)C)C2)cc1)S(=O)(=O)Cc1ccccc1"]
    lista_smiles = ["CC(C)OC(=O)CC(=O)CSc1nc2c(cc1C#N)CCC2", "opaaa"]
    teste_new_admet(lista_smiles)
    #get_admet_results()
