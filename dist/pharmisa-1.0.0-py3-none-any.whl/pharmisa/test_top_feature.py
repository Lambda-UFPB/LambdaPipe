from pharma_optimizer import PharmaOptimizer
from top_feature_configs import run_feature_configs
from json_handler import JsonHandler
import json

with open('/home/kdunorat/Projetos/LambdaPipe/files/pharmit (8).json', 'r') as file:
    json_teste = json.load(file)
plip_csv = '/home/kdunorat/Projetos/LambdaPipe/files/7DK5-272.csv'
popt = PharmaOptimizer(json_teste, plip_csv)
pharmit_spheres_list = popt.run_pharma_optimizer()

configs_list = run_feature_configs(pharmit_spheres_list)
jsh = JsonHandler(output_file_path='/home/kdunorat/Projetos/LambdaPipe/files', pharmit_json='/home/kdunorat/Projetos/LambdaPipe/files/pharmit (8).json')
for index, config in enumerate(configs_list):
    jsh.write_points(config)
    new = jsh.create_json(file_index=index+1)

