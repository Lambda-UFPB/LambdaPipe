class InvalidInputError(Exception):
    pass


class BadAdmetSmilesError(Exception):
    pass


class AdmetServerError(Exception):
    pass


class NoMoleculeError(Exception):
    pass
